//@ts-check
"use strict";

import setLink from "./setLink.js";
import modifyChart from "./modifyChart.js";
import chartParams from "./chartParams.js";

$( function() {

	const linkParams = {
		month: "2021-01",
		day: undefined,
		token: "kx8Lm6spO9Lx6xNa8lNC61Kx20Ql37",
		sort_by: "hours_watched",
		order: "desc",
		limit: "25",
		offset: "0"
	}

	let dataArray = [];
	let dataNumbers = [];

	const link = setLink(linkParams);

	fetch("https://api.streamhatchet.com/discovery/games/" + link)
	.then((res) => res.json())
	.then((data) => {
		dataArray = data;
		console.log(dataArray);
		// modifyChart();
	});

	for(let i=0; i< parseInt(linkParams.limit); i++) {
		dataNumbers += [data.games[i].game, data.games[i][linkParams.sort_by]]

	}

	chartParams.yAxis.title.text = linkParams.sort_by;
	chartParams.series["data"] = linkParams.sort_by;

	const Highcharts = window["Highcharts"];

	Highcharts.chart('container', chartParams);

});
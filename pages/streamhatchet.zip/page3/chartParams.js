const chartParams = {
	title: {
		text: 'Game statistics'
	},
	subtitle: {
		text: 'Source: Stream Hatchet'
	},
	chart: {
    type: 'column'
  },
	xAxis: {
    type: 'category',
    labels: {
      rotation: -45,
      style: {
        fontSize: '13px',
        fontFamily: 'Verdana, sans-serif'
      }
    }
  },
  yAxis: {
    min: 0,
    title: {
      text: 'Population (millions)'
    }
  },
  legend: {
    enabled: false
  },
  tooltip: {
    pointFormat: 'Population in 2021: <b>{point.y:.1f} millions</b>'
  },
  series: [{
    name: 'Population',
    data: [
      ['Tokyo', 37.33],
      ['Delhi', 31.18],
      ['Shanghai', 27.79],
      ['Sao Paulo', 22.23],
      ['Mexico City', 21.91],
      ['Dhaka', 21.74],
      ['Cairo', 21.32],
      ['Beijing', 20.89],
      ['Mumbai', 20.67],
      ['Osaka', 19.11],
      ['Karachi', 16.45],
      ['Chongqing', 16.38],
      ['Istanbul', 15.41],
      ['Buenos Aires', 15.25],
      ['Kolkata', 14.974],
      ['Kinshasa', 14.970],
      ['Lagos', 14.86],
      ['Manila', 14.16],
      ['Tianjin', 13.79],
      ['Guangzhou', 13.64]
    ],
    dataLabels: {
      enabled: true,
      rotation: -90,
      color: '#FFFFFF',
      align: 'right',
      format: '{point.y:.1f}', // one decimal
      y: 10, // 10 pixels down from the top
      style: {
        fontSize: '13px',
        fontFamily: 'Verdana, sans-serif'
      }
    }
  }]
}

// function getNewPoint() {
// 	var x = (new Date()).getTime(), // current time
// 			y = Math.random();
	
// 	return Math.random()*10>7.5 ? [x,y] : false;
// }

// const chartParams = {
// 	chart: {
// 	renderTo: 'container',
// 	defaultSeriesType: 'spline',
// 	marginRight: 10,
// 	events: {
// 		load: function() {
// 		// set up the updating of the chart each second
// 		var series = this.series[0];
// 		setInterval(function() {
// 			var point = getNewPoint();
		
// 			if (point)
// 				series.addPoint(point, true, true);
// 		}, 1000);
// 		}
// 	}
// },
// title: {
// 	text: 'Live random data'
// },
// xAxis: {
// 	type: 'datetime',
// 	tickPixelInterval: 150
// },
// yAxis: {
// 	title: {
// 		 text: 'Value'
// 	},
// 	plotLines: [{
// 		 value: 0,
// 		 width: 1,
// 		 color: '#808080'
// 	}]
// },
// tooltip: {
// 	formatter: function() {
// 						return '<b>'+ this.series.name +'</b><br/>'+
// 				Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', this.x) +'<br/>'+ 
// 				Highcharts.numberFormat(this.y, 2);
// 	}
// },
// legend: {
// 	enabled: false
// },
// exporting: {
// 	enabled: false
// },
// series: [{
// 	name: 'Random data',
// 	data: (function() {
// 		 // generate an array of random data
// 		 let data = [],
// 				time = (new Date()).getTime(),
// 				i;
		 
// 		 for (i = -19; i <= 0; i++) {
// 				data.push({
// 					 x: time + i * 1000,
// 					 y: Math.random()
// 				});
// 		 }
// 		 return data;
// 	})()
// }]
// }

export default chartParams
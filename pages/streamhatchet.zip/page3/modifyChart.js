function modifyChart(linkParams) {

}

export default modifyChart;